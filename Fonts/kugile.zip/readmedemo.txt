This demo font is free for PERSONAL USE, but any donation are very appreciated

Here is the link to purchase commercial license:
https://creativemarket.com/Pentagonistudio/7168509-Kugile-Classy-Serif-Font

For Corporate use you have to purchase Corporate license

You can purchase here too :
https://creativemarket.com/Pentagonistudio

If you need a custom license please contact us at
pentagonistudio@gmail.com

Paypal donation : https://paypal.me/pentagonistudio

Visit our store for more great fonts :
https://pentagonistudio.com/

Thank you!

